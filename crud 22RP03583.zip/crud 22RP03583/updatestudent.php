<?php
include 'session.php';
include'connecton.php';

$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM students WHERE id='$id'");
$student = mysqli_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];

    $sql = "UPDATE students SET name='$name', email='$email' WHERE id='$id'";
    if (mysqli_query($conn, $sql)) {
        header("Location: students.php");
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Student</title>
</head>
<body>
    <h2>update student Student</h2>
    <form method="post" action="">
        Name: <input type="text" name="name" value="<?php echo $student['name']; ?>" required><br>
        Email: <input type="email" name="email" value="<?php echo $student['email']; ?>" required><br>
        <input type="submit" value="Updatestudent">
    </form>
</body>
</html>
