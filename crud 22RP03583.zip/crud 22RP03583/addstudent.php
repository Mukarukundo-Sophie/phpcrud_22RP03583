<?php
include 'session.php';
include  'connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];

    $sql = "INSERT INTO students (name, email) VALUES ('$name', '$email')";
    if (mysqli_query($conn, $sql)) {
        header("Location: students.php");
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>AddStudent</title>
</head>
<body>
    <h2>create new student:</h2>
    <form method="post" action="">
        name: <input type="text" name="name"><br>
        Email: <input type="email" name="email"><br>
        <input type="submit" value="newstudent">
    </form>
</body>
</html>

